# TapMaster – Otomatik tıklayıcı / makro (Android)

Yüzen panelli otomatik tıklayıcı: dokunma, uzun basma, kaydırma, kayıt, döngü, hız,
rastgele sapma, otomatik durdurma ve kayıtlı makrolar.

## APK'yı telefondan derleme (bilgisayar gerekmez)

1. github.com'da ücretsiz hesap aç, yeni bir **boş repo** oluştur.
2. Bu klasörün içindeki **tüm dosyaları** (gizli `.github` klasörü dahil) repoya yükle.
3. Repoda **Actions** sekmesine gir → "APK derle" çalışır (2–4 dk).
4. Bittiğinde çalışmanın içindeki **TapMaster-apk** dosyasını indir, zip'i aç, `app-debug.apk`'yı yükle.
   (Bilinmeyen kaynaklardan yüklemeye izin vermen istenebilir.)

## Bilgisayarda derleme

Android Studio ile klasörü aç → Build → Build APK. Ya da: `gradle assembleDebug`
(JDK 17 + Android SDK gerekir). APK: `app/build/outputs/apk/debug/app-debug.apk`

## İlk kurulum

1. Uygulamayı aç → **Erişilebilirlik ayarlarını aç** → TapMaster → **Aç**.
   (Android 13+ ve bazı cihazlarda "kısıtlı ayar" için: Ayarlar → Uygulamalar → TapMaster → ⋮ → *Kısıtlı ayarlara izin ver*.)
2. Uygulamaya dön → **Yüzen paneli göster**.

## Panel

| Tuş | İş |
|---|---|
| ⋮ | Sürükle: taşı • Dokun: daralt/genişlet |
| ▶ / ■ | Başlat / durdur |
| + | Dokunma noktası ekle |
| ↔ | Kaydırma ekle (yeşil başlangıç, turuncu bitiş) |
| L | Uzun basma noktası ekle |
| ● | Kayıt modu aç/kapat |
| 🗑 | Tüm noktaları sil |
| ✕ | Paneli kapat |

Numaralı daireleri sürükleyerek yerleştir, silmek için daireye uzun bas.
Adım bekleme süreleri, döngü, hız, sapma ve makro kaydetme ana ekrandan ayarlanır.

## Notlar

- Kayıt modunda ekran dokunuşları yakalanır, oyuna iletilmez.
- Bazı oyunlar/bankacılık uygulamaları erişilebilirlik servislerini engelleyebilir.
- Online oyunlarda otomatik tıklayıcı kullanımı oyunun kurallarına aykırı olabilir; sorumluluk kullanıcıdadır.
