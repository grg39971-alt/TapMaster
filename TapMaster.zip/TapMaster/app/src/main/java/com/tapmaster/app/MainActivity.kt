package com.tapmaster.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var root: LinearLayout
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Colors.BG)
            fitsSystemWindows = true
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(32))
        }
        scroll.addView(root, ViewGroup.LayoutParams(MATCH, WRAP))
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    // ------------------------------------------------------------ küçük yardımcılar

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun card(title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Colors.CARD, dp(18).toFloat())
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        c.addView(text(title, 16f, Colors.TEXT, true))
        root.addView(c, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) })
        return c
    }

    private fun button(label: String, color: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(color, dp(14).toFloat())
            setPadding(dp(12), dp(13), dp(12), dp(13))
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) }
            setOnClickListener { onClick() }
        }

    private fun chip(label: String, minWidthDp: Int = 40): TextView =
        TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(Colors.TEXT)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(Colors.CHIP, dp(10).toFloat())
            minWidth = dp(minWidthDp)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(6) }
        }

    private fun askNumber(title: String, current: Long, onOk: (Long) -> Unit) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(current.toString())
            setSelection(text.length)
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("Tamam") { _, _ ->
                input.text.toString().trim().toLongOrNull()?.let(onOk)
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    /** − değer + satırı. Değere dokununca sayı girilebilir. */
    private fun stepper(
        parent: LinearLayout,
        label: String,
        get: () -> Long,
        set: (Long) -> Unit,
        step: Long,
        min: Long,
        max: Long,
        suffix: String
    ): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        row.addView(
            text(label, 14f, Colors.TEXT).apply {
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            }
        )
        val minus = chip("−")
        val value = chip("${get()}$suffix", 64)
        val plus = chip("+")

        fun commit(v: Long) {
            set(v.coerceIn(min, max))
            value.text = "${get()}$suffix"
            Store.save()
        }
        minus.setOnClickListener { commit(get() - step) }
        plus.setOnClickListener { commit(get() + step) }
        value.setOnClickListener { askNumber(label, get()) { v -> commit(v) } }

        row.addView(minus)
        row.addView(value)
        row.addView(plus)
        parent.addView(row)
        return row
    }

    private fun isServiceOn(): Boolean = ClickService.instance != null

    private fun typeName(t: Type): String = when (t) {
        Type.TAP -> "Dokun"
        Type.LONG -> "Uzun bas"
        Type.SWIPE -> "Kaydır"
    }

    // ------------------------------------------------------------ ekran

    private fun render() {
        root.removeAllViews()

        root.addView(text("TapMaster", 30f, Colors.TEXT, true))
        root.addView(text("Otomatik tıklayıcı ve makro", 14f, Colors.MUTED))

        // --- kurulum
        val setup = card("Kurulum")
        val on = isServiceOn()
        setup.addView(
            text(
                if (on) "● Servis açık" else "○ Servis kapalı",
                14f,
                if (on) Colors.GREEN else Colors.RED
            ).apply { setPadding(0, dp(8), 0, 0) }
        )
        if (!on) {
            setup.addView(
                text(
                    "Ayarlar → Erişilebilirlik → Yüklü uygulamalar → TapMaster → Aç. " +
                            "Bu izin, uygulamanın senin belirlediğin noktalara dokunabilmesi için gerekir.",
                    13f, Colors.MUTED
                ).apply { setPadding(0, dp(6), 0, 0) }
            )
            setup.addView(button("Erişilebilirlik ayarlarını aç", Colors.ACCENT) {
                startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
        } else {
            val visible = ClickService.instance?.isPanelVisible() == true
            setup.addView(
                button(
                    if (visible) "Yüzen paneli gizle" else "Yüzen paneli göster",
                    if (visible) Colors.RED else Colors.GREEN
                ) {
                    ClickService.instance?.togglePanel()
                    render()
                }
            )
            if (!visible) {
                setup.addView(
                    text(
                        "Paneli açtıktan sonra oyuna/uygulamaya geç; panel üstte kalır.",
                        13f, Colors.MUTED
                    ).apply { setPadding(0, dp(8), 0, 0) }
                )
            }
        }

        // --- ayarlar
        val cfg = Store.cfg
        val set = card("Ayarlar")
        stepper(set, "Yeni noktaların beklemesi", { cfg.defaultDelayMs }, { cfg.defaultDelayMs = it }, 50, 10, 60000, " ms")
        stepper(set, "Döngü sayısı (0 = sonsuz)", { cfg.loops }, { cfg.loops = it }, 1, 0, 1000000, "")
        stepper(set, "Hız", { cfg.speedPct }, { cfg.speedPct = it }, 10, 10, 1000, "%")
        stepper(set, "Konum sapması", { cfg.jitterPx }, { cfg.jitterPx = it }, 1, 0, 50, " px")
        stepper(set, "Bekleme sapması", { cfg.delayJitterPct }, { cfg.delayJitterPct = it }, 5, 0, 90, "%")
        stepper(set, "Otomatik durdur (0 = kapalı)", { cfg.stopAfterSec }, { cfg.stopAfterSec = it }, 10, 0, 86400, " sn")

        // --- aktif makro
        val acts = Store.actions
        val cur = card("Aktif makro (${acts.size} adım)")
        if (acts.isEmpty()) {
            cur.addView(
                text(
                    "Henüz adım yok. Yüzen panelde + ile nokta ekle ya da ● ile kayıt yap.",
                    13f, Colors.MUTED
                ).apply { setPadding(0, dp(8), 0, 0) }
            )
        } else {
            cur.addView(text("Her adımın önündeki bekleme süresi:", 12f, Colors.MUTED).apply {
                setPadding(0, dp(6), 0, 0)
            })
            acts.forEachIndexed { i, a ->
                val row = stepper(
                    cur, "${i + 1} • ${typeName(a.type)}",
                    { a.delayMs }, { a.delayMs = it }, 50, 0, 600000, " ms"
                )
                val del = chip("✕").apply { setTextColor(Colors.RED) }
                del.setOnClickListener {
                    Store.actions.remove(a)
                    Store.save()
                    ClickService.instance?.refresh()
                    render()
                }
                row.addView(del)
            }
            cur.addView(button("Tüm adımları temizle", Colors.CHIP) {
                Store.actions.clear()
                Store.save()
                ClickService.instance?.refresh()
                render()
            })
        }
        cur.addView(button("Bu makroyu kaydet", Colors.ACCENT) {
            if (Store.actions.isEmpty()) {
                Toast.makeText(this, "Kaydedilecek adım yok", Toast.LENGTH_SHORT).show()
            } else {
                val input = EditText(this).apply {
                    hint = "Makro adı"
                    inputType = InputType.TYPE_CLASS_TEXT
                }
                AlertDialog.Builder(this)
                    .setTitle("Makroyu kaydet")
                    .setView(input)
                    .setPositiveButton("Kaydet") { _, _ ->
                        val n = input.text.toString().trim()
                        if (n.isNotEmpty()) {
                            Store.saveMacro(n)
                            render()
                        }
                    }
                    .setNegativeButton("İptal", null)
                    .show()
            }
        })

        // --- kayıtlı makrolar
        val saved = card("Kayıtlı makrolar")
        val names = Store.macroNames()
        if (names.isEmpty()) {
            saved.addView(text("Henüz kayıtlı makro yok.", 13f, Colors.MUTED).apply {
                setPadding(0, dp(8), 0, 0)
            })
        }
        for (n in names) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(10), 0, 0)
            }
            row.addView(text(n, 14f, Colors.TEXT).apply {
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            })
            val load = chip("Yükle", 56).apply { setTextColor(Colors.GREEN) }
            val del = chip("Sil", 48).apply { setTextColor(Colors.RED) }
            load.setOnClickListener {
                Store.loadMacro(n)
                ClickService.instance?.refresh()
                Toast.makeText(this, "\"$n\" yüklendi", Toast.LENGTH_SHORT).show()
                render()
            }
            del.setOnClickListener {
                Store.deleteMacro(n)
                render()
            }
            row.addView(load)
            row.addView(del)
            saved.addView(row)
        }

        // --- yardım
        val help = card("Nasıl kullanılır?")
        help.addView(
            text(
                "1. Servisi aç, \"Yüzen paneli göster\"e bas.\n" +
                        "2. Oyuna geç. Panelde + (dokun), ↔ (kaydır), L (uzun bas) ile nokta ekle.\n" +
                        "3. Numaralı daireleri sürükleyip yerleştir; silmek için daireye uzun bas.\n" +
                        "4. ▶ ile başlat, ■ ile durdur.\n\n" +
                        "● Kayıt: açıkken ekrana yaptığın dokunma/kaydırma ve aradaki süreler adım olarak kaydedilir " +
                        "(kayıt sırasında dokunuşlar oyuna geçmez).\n\n" +
                        "⋮ tutamağı: sürükle = paneli taşı, dokun = daralt/genişlet.",
                13f, Colors.MUTED
            ).apply { setPadding(0, dp(8), 0, 0) }
        )
    }
}
