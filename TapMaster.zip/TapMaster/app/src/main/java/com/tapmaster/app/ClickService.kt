package com.tapmaster.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Random
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * Hem hareketleri uygulayan (dispatchGesture) hem de yüzen paneli/işaretçileri
 * çizen erişilebilirlik servisi. Pencereler TYPE_ACCESSIBILITY_OVERLAY olduğu için
 * ayrıca "diğer uygulamaların üzerinde göster" izni gerekmez.
 */
class ClickService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ClickService? = null
    }

    private class Marker(
        val view: TextView,
        val lp: WindowManager.LayoutParams,
        val act: Act,
        val isEnd: Boolean
    )

    private val MP = WindowManager.LayoutParams.MATCH_PARENT
    private val WC = WindowManager.LayoutParams.WRAP_CONTENT

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var panel: LinearLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var px = 40
    private var py = 300
    private var collapsed = false

    private val markers = ArrayList<Marker>()
    private var lines: LinesView? = null
    private var recordView: View? = null

    private var panelOn = false
    private var recording = false
    @Volatile
    private var running = false

    private val size: Int by lazy { dp(44) }

    // ---------------------------------------------------------------- yaşam döngüsü

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Store.init(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        try {
            hidePanel()
        } catch (_: Exception) {
        }
        instance = null
        return super.onUnbind(intent)
    }

    // ---------------------------------------------------------------- dışarıya açık

    fun isPanelVisible(): Boolean = panelOn

    fun togglePanel() {
        if (panelOn) hidePanel() else showPanel()
    }

    fun showPanel() {
        if (panelOn) return
        panelOn = true
        refresh()
    }

    fun hidePanel() {
        running = false
        recording = false
        panelOn = false
        main.post {
            stopRecordView()
            clearOverlays()
            removePanel()
        }
    }

    /** Markörleri ve paneli Store'daki verilere göre yeniden çizer. */
    fun refresh() {
        main.post {
            if (!panelOn) return@post
            clearOverlays()
            if (!recording) buildMarkers()
            addPanelOnTop()
        }
    }

    // ---------------------------------------------------------------- pencere yardımcıları

    private fun lp(w: Int, h: Int, touchable: Boolean = true): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val dm = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    }

    @Suppress("DEPRECATION")
    private fun vibrate(ms: Long = 40) {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                v.vibrate(ms)
            }
        } catch (_: Exception) {
        }
    }

    private fun safeRemove(v: View?) {
        if (v == null) return
        try {
            wm.removeView(v)
        } catch (_: Exception) {
        }
    }

    private fun clearOverlays() {
        for (m in markers) safeRemove(m.view)
        markers.clear()
        safeRemove(lines)
        lines = null
    }

    private fun removePanel() {
        safeRemove(panel)
        panel = null
        panelLp = null
    }

    // ---------------------------------------------------------------- işaretçiler

    private fun buildMarkers() {
        val touchable = !running
        val lv = LinesView(this)
        lines = lv
        wm.addView(lv, lp(MP, MP, false))
        Store.actions.forEachIndexed { i, a ->
            addMarker(a, i + 1, false, touchable)
            if (a.type == Type.SWIPE) addMarker(a, i + 1, true, touchable)
        }
    }

    private fun addMarker(a: Act, n: Int, isEnd: Boolean, touchable: Boolean) {
        val color = when {
            isEnd -> Colors.ORANGE
            a.type == Type.TAP -> Colors.ACCENT
            a.type == Type.LONG -> Colors.PURPLE
            else -> Colors.GREEN
        }
        val tv = TextView(this).apply {
            text = n.toString()
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(color, size / 2f, Color.WHITE, dp(2))
            alpha = if (touchable) 0.95f else 0.3f
        }
        val p = lp(size, size, touchable)
        val cx = if (isEnd) a.x2 else a.x
        val cy = if (isEnd) a.y2 else a.y
        p.x = (cx - size / 2f).toInt()
        p.y = (cy - size / 2f).toInt()
        val m = Marker(tv, p, a, isEnd)
        attachDrag(m)
        wm.addView(tv, p)
        markers.add(m)
    }

    private fun attachDrag(m: Marker) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var t0 = 0L
        var moved = false
        m.view.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    sy = e.rawY
                    ox = m.lp.x
                    oy = m.lp.y
                    t0 = SystemClock.elapsedRealtime()
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!moved && hypot(dx, dy) > dp(8)) moved = true
                    if (moved) {
                        m.lp.x = (ox + dx).toInt()
                        m.lp.y = (oy + dy).toInt()
                        try {
                            wm.updateViewLayout(m.view, m.lp)
                        } catch (_: Exception) {
                        }
                        val cx = m.lp.x + size / 2f
                        val cy = m.lp.y + size / 2f
                        if (m.isEnd) {
                            m.act.x2 = cx
                            m.act.y2 = cy
                        } else {
                            m.act.x = cx
                            m.act.y = cy
                        }
                        lines?.invalidate()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        Store.save()
                    } else if (SystemClock.elapsedRealtime() - t0 > 600) {
                        vibrate()
                        Store.actions.remove(m.act)
                        Store.save()
                        refresh()
                    }
                }
            }
            true
        }
    }

    private fun setMarkersTouchable(t: Boolean) {
        for (m in markers) {
            if (t) {
                m.lp.flags = m.lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            } else {
                m.lp.flags = m.lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            }
            m.view.alpha = if (t) 0.95f else 0.3f
            try {
                wm.updateViewLayout(m.view, m.lp)
            } catch (_: Exception) {
            }
        }
    }

    private inner class LinesView(ctx: Context) : View(ctx) {
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xCCF39C12.toInt()
            strokeWidth = dp(3).toFloat()
            style = Paint.Style.STROKE
        }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xCCF39C12.toInt()
            style = Paint.Style.FILL
        }

        override fun onDraw(c: Canvas) {
            for (a in Store.actions) {
                if (a.type != Type.SWIPE) continue
                c.drawLine(a.x, a.y, a.x2, a.y2, stroke)
                val mx = (a.x + a.x2) / 2f
                val my = (a.y + a.y2) / 2f
                val ang = atan2(a.y2 - a.y, a.x2 - a.x)
                val len = dp(16).toFloat()
                val head = Path()
                head.moveTo(mx + len * 0.6f * cos(ang), my + len * 0.6f * sin(ang))
                head.lineTo(mx - len * cos(ang - 0.5f), my - len * sin(ang - 0.5f))
                head.lineTo(mx - len * cos(ang + 0.5f), my - len * sin(ang + 0.5f))
                head.close()
                c.drawPath(head, fill)
            }
        }
    }

    // ---------------------------------------------------------------- yüzen panel

    private fun pBtn(label: String, color: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(color, dp(20).toFloat())
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply {
                setMargins(dp(2), 0, dp(2), 0)
            }
            setOnClickListener { onClick() }
        }

    private fun addPanelOnTop() {
        removePanel()
        if (!panelOn) return

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(0xE6171B22.toInt(), dp(28).toFloat(), 0x33FFFFFF, dp(1))
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }

        // sürükleme + daralt/genişlet tutamağı
        val handle = TextView(this).apply {
            text = "⋮"
            gravity = Gravity.CENTER
            setTextColor(Colors.MUTED)
            textSize = 20f
            layoutParams = LinearLayout.LayoutParams(dp(24), dp(40))
        }
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    sy = e.rawY
                    ox = px
                    oy = py
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!moved && hypot(dx, dy) > dp(6)) moved = true
                    if (moved) {
                        px = (ox + dx).toInt()
                        py = (oy + dy).toInt()
                        panelLp?.let {
                            it.x = px
                            it.y = py
                            try {
                                wm.updateViewLayout(root, it)
                            } catch (_: Exception) {
                            }
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        collapsed = !collapsed
                        main.post { addPanelOnTop() }
                    }
                }
            }
            true
        }
        root.addView(handle)

        // oynat / durdur
        root.addView(
            pBtn(if (running) "■" else "▶", if (running) Colors.RED else Colors.GREEN) {
                if (running) stopRun() else startRun()
            }
        )

        if (!collapsed) {
            root.addView(pBtn("+", Colors.ACCENT) { addPoint(Type.TAP) })
            root.addView(pBtn("↔", Colors.GREEN) { addPoint(Type.SWIPE) })
            root.addView(pBtn("L", Colors.PURPLE) { addPoint(Type.LONG) })
            root.addView(
                pBtn("●", if (recording) Colors.RED else Colors.CHIP) {
                    if (recording) stopRecord() else startRecord()
                }
            )
            root.addView(pBtn("🗑", Colors.CHIP) { clearAll() })
            root.addView(pBtn("✕", Colors.CHIP) { hidePanel() })
        }

        val p = lp(WC, WC)
        p.x = px
        p.y = py
        panel = root
        panelLp = p
        wm.addView(root, p)
    }

    private fun clearAll() {
        if (running || recording) return
        Store.actions.clear()
        Store.save()
        refresh()
        toast("Tüm noktalar silindi")
    }

    private fun addPoint(type: Type) {
        if (running) return
        if (recording) {
            toast("Önce kaydı durdur")
            return
        }
        val (w, h) = screenSize()
        val off = (Store.actions.size % 6) * dp(18)
        val d = Store.cfg.defaultDelayMs
        val a = when (type) {
            Type.TAP -> Act(Type.TAP, w / 2f + off, h / 2f + off, holdMs = 50, delayMs = d)
            Type.LONG -> Act(Type.LONG, w / 2f + off, h / 2f + off, holdMs = 800, delayMs = d)
            Type.SWIPE -> Act(
                Type.SWIPE, w * 0.35f, h * 0.55f + off, w * 0.65f, h * 0.55f + off,
                holdMs = 300, delayMs = d
            )
        }
        Store.actions.add(a)
        Store.save()
        refresh()
        toast("Noktayı sürükleyerek yerleştir • silmek için uzun bas")
    }

    // ---------------------------------------------------------------- kayıt modu

    private fun startRecord() {
        if (running) return
        if (recording) return
        recording = true
        clearOverlays()

        val v = View(this)
        v.setBackgroundColor(0x22FF3B30)
        var downT = 0L
        var dx = 0f
        var dy = 0f
        var lastUp = SystemClock.elapsedRealtime()
        var first = true
        var count = 0
        v.setOnTouchListener { _, e ->
            val now = SystemClock.elapsedRealtime()
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downT = now
                    dx = e.rawX
                    dy = e.rawY
                }
                MotionEvent.ACTION_UP -> {
                    val dur = max(now - downT, 1L)
                    val dist = hypot(e.rawX - dx, e.rawY - dy)
                    val delay = if (first) Store.cfg.defaultDelayMs else max(downT - lastUp, 10L)
                    first = false
                    lastUp = now
                    val a = when {
                        dist > dp(24) -> Act(
                            Type.SWIPE, dx, dy, e.rawX, e.rawY,
                            dur.coerceIn(50L, 5000L), delay
                        )
                        dur >= 450 -> Act(
                            Type.LONG, dx, dy,
                            holdMs = dur.coerceIn(450L, 10000L), delayMs = delay
                        )
                        else -> Act(
                            Type.TAP, dx, dy,
                            holdMs = dur.coerceIn(20L, 300L), delayMs = delay
                        )
                    }
                    Store.actions.add(a)
                    Store.save()
                    count++
                    vibrate(15)
                }
            }
            true
        }
        recordView = v
        wm.addView(v, lp(MP, MP))
        addPanelOnTop()
        toast("Kayıt açık: ekrana dokun/kaydır. Bitirince ● tuşuna bas")
    }

    private fun stopRecordView() {
        safeRemove(recordView)
        recordView = null
    }

    private fun stopRecord() {
        recording = false
        stopRecordView()
        refresh()
        toast("Kayıt bitti: ${Store.actions.size} adım")
    }

    // ---------------------------------------------------------------- çalıştırma

    private fun startRun() {
        if (running) return
        if (recording) {
            toast("Önce kaydı durdur")
            return
        }
        if (Store.actions.isEmpty()) {
            toast("Önce + ile bir nokta ekle")
            return
        }
        running = true
        val acts = Store.actions.map { it.copy() }
        val s = Store.cfg.copy()
        setMarkersTouchable(false)
        addPanelOnTop()

        Thread {
            val rnd = Random()
            val t0 = SystemClock.elapsedRealtime()
            var loop = 0L
            try {
                while (running && (s.loops == 0L || loop < s.loops)) {
                    for (a in acts) {
                        if (!running) break
                        var d = a.delayMs * 100L / max(s.speedPct, 10L)
                        if (s.delayJitterPct > 0) {
                            val r = rnd.nextInt((2 * s.delayJitterPct + 1).toInt()) - s.delayJitterPct
                            d += d * r / 100L
                        }
                        if (!sleepWhileRunning(max(d, 0L))) break
                        if (s.stopAfterSec > 0 &&
                            SystemClock.elapsedRealtime() - t0 > s.stopAfterSec * 1000L
                        ) {
                            running = false
                            break
                        }
                        perform(a, s, rnd)
                    }
                    loop++
                }
            } finally {
                running = false
                main.post {
                    if (panelOn) {
                        setMarkersTouchable(true)
                        addPanelOnTop()
                    }
                }
            }
        }.also {
            it.isDaemon = true
            it.start()
        }
    }

    private fun stopRun() {
        running = false
    }

    private fun sleepWhileRunning(ms: Long): Boolean {
        var left = ms
        while (left > 0) {
            if (!running) return false
            val step = if (left > 20) 20L else left
            try {
                Thread.sleep(step)
            } catch (_: InterruptedException) {
                return false
            }
            left -= step
        }
        return running
    }

    private fun perform(a: Act, s: Config, r: Random) {
        fun j(): Float =
            if (s.jitterPx > 0) (r.nextInt((2 * s.jitterPx + 1).toInt()) - s.jitterPx).toFloat() else 0f

        val path = Path()
        path.moveTo(a.x + j(), a.y + j())
        if (a.type == Type.SWIPE) path.lineTo(a.x2 + j(), a.y2 + j())

        val dur = when (a.type) {
            Type.TAP -> a.holdMs.coerceIn(1L, 500L)
            Type.LONG -> a.holdMs.coerceIn(300L, 10000L)
            Type.SWIPE -> a.holdMs.coerceIn(50L, 10000L)
        }

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, dur))
            .build()

        val latch = CountDownLatch(1)
        val ok = dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                latch.countDown()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                latch.countDown()
            }
        }, null)
        if (ok) latch.await(dur + 1500L, TimeUnit.MILLISECONDS)
    }
}
