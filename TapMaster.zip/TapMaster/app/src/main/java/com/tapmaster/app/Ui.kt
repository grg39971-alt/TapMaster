package com.tapmaster.app

import android.content.Context
import android.graphics.drawable.GradientDrawable

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun rounded(color: Int, radiusPx: Float, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusPx
        if (strokePx > 0) setStroke(strokePx, strokeColor)
    }

object Colors {
    val BG = 0xFF0E1116.toInt()
    val CARD = 0xFF171B22.toInt()
    val CHIP = 0xFF252B35.toInt()
    val TEXT = 0xFFE8ECF2.toInt()
    val MUTED = 0xFF8B95A5.toInt()
    val ACCENT = 0xFF4F8CFF.toInt()
    val GREEN = 0xFF2ECC71.toInt()
    val RED = 0xFFE5484D.toInt()
    val ORANGE = 0xFFF39C12.toInt()
    val PURPLE = 0xFF9B59B6.toInt()
}
