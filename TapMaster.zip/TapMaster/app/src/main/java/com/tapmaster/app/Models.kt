package com.tapmaster.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

enum class Type { TAP, LONG, SWIPE }

data class Act(
    var type: Type,
    var x: Float,
    var y: Float,
    var x2: Float = 0f,
    var y2: Float = 0f,
    var holdMs: Long = 50,
    var delayMs: Long = 200
) {
    fun toJson(): JSONObject = JSONObject()
        .put("t", type.name)
        .put("x", x.toDouble())
        .put("y", y.toDouble())
        .put("x2", x2.toDouble())
        .put("y2", y2.toDouble())
        .put("h", holdMs)
        .put("d", delayMs)

    companion object {
        fun fromJson(o: JSONObject): Act = Act(
            Type.valueOf(o.optString("t", "TAP")),
            o.optDouble("x", 0.0).toFloat(),
            o.optDouble("y", 0.0).toFloat(),
            o.optDouble("x2", 0.0).toFloat(),
            o.optDouble("y2", 0.0).toFloat(),
            o.optLong("h", 50),
            o.optLong("d", 200)
        )
    }
}

data class Config(
    var loops: Long = 0,            // 0 = sonsuz
    var speedPct: Long = 100,       // %10 .. %1000
    var jitterPx: Long = 0,         // konum sapması
    var delayJitterPct: Long = 0,   // bekleme sapması (%)
    var stopAfterSec: Long = 0,     // 0 = kapalı
    var defaultDelayMs: Long = 200  // yeni noktaların varsayılan beklemesi
) {
    fun toJson(): JSONObject = JSONObject()
        .put("loops", loops)
        .put("speed", speedPct)
        .put("jitter", jitterPx)
        .put("djitter", delayJitterPct)
        .put("stop", stopAfterSec)
        .put("delay", defaultDelayMs)

    companion object {
        fun fromJson(o: JSONObject): Config = Config(
            o.optLong("loops", 0),
            o.optLong("speed", 100),
            o.optLong("jitter", 0),
            o.optLong("djitter", 0),
            o.optLong("stop", 0),
            o.optLong("delay", 200)
        )
    }
}

object Store {
    private var prefs: SharedPreferences? = null
    val actions = ArrayList<Act>()
    var cfg = Config()

    @Synchronized
    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("tapmaster", Context.MODE_PRIVATE)
        prefs = p
        try {
            p.getString("cfg", null)?.let { cfg = Config.fromJson(JSONObject(it)) }
            p.getString("current", null)?.let { actions.addAll(parse(JSONArray(it))) }
        } catch (_: Exception) {
        }
    }

    private fun parse(a: JSONArray): List<Act> {
        val l = ArrayList<Act>()
        for (i in 0 until a.length()) l.add(Act.fromJson(a.getJSONObject(i)))
        return l
    }

    private fun toArray(list: List<Act>): JSONArray {
        val a = JSONArray()
        for (x in list) a.put(x.toJson())
        return a
    }

    fun save() {
        prefs?.edit()
            ?.putString("cfg", cfg.toJson().toString())
            ?.putString("current", toArray(actions).toString())
            ?.apply()
    }

    private fun macroObj(): JSONObject = try {
        JSONObject(prefs?.getString("macros", "{}") ?: "{}")
    } catch (_: Exception) {
        JSONObject()
    }

    fun macroNames(): List<String> {
        val it = macroObj().keys()
        val l = ArrayList<String>()
        while (it.hasNext()) l.add(it.next())
        return l.sorted()
    }

    fun saveMacro(name: String) {
        val o = macroObj()
        o.put(name, toArray(actions))
        prefs?.edit()?.putString("macros", o.toString())?.apply()
    }

    fun loadMacro(name: String) {
        val a = macroObj().optJSONArray(name) ?: return
        actions.clear()
        actions.addAll(parse(a))
        save()
    }

    fun deleteMacro(name: String) {
        val o = macroObj()
        o.remove(name)
        prefs?.edit()?.putString("macros", o.toString())?.apply()
    }
}
